#include <stdio.h>
#include "pico/stdlib.h"

int main() {
  stdio_init_all();
  gpio_init(25);
  gpio_set_dir(25, true);
  gpio_init(10);
  gpio_set_dir(10,false);
  
  while(true) {

    char boton = gpio_get(10);
    char led = gpio_get(25);

    if (boton) {

      if (led) {
        gpio_put(25,false);
      }
      else {
        gpio_put(25,true);
      }
    }
    sleep_ms(500);
  }
}
